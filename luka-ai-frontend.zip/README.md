
# Luka AI — Frontend (Modern Clean AI Look)

This is a simple static frontend for Luka AI (Free Online Photo Editor).

Files:
- index.html
- style.css
- script.js

How to use:
1. Upload these three files to your GitHub repo (or Netlify Drop).
2. This is a frontend only: to get real AI results you need a server API at /api/hug-pose (I provided a server example earlier).

If you want, I can also provide the server files again and help deploy to Vercel.
