
const file1 = document.getElementById('file1')
const file2 = document.getElementById('file2')
const previewRow = document.getElementById('previewRow')
const generateBtn = document.getElementById('generateBtn')
const clearBtn = document.getElementById('clearBtn')
const statusP = document.getElementById('status')
const resultCard = document.getElementById('resultCard')
const resultArea = document.getElementById('resultArea')
const downloadLink = document.getElementById('downloadLink')
const backBtn = document.getElementById('backBtn')

function showStatus(msg){ statusP.textContent = msg }

function updatePreviews(){
  previewRow.innerHTML=''
  [file1,file2].forEach(finput => {
    if(finput.files && finput.files[0]){
      const img = document.createElement('img')
      img.src = URL.createObjectURL(finput.files[0])
      previewRow.appendChild(img)
    }
  })
}

file1.addEventListener('change', updatePreviews)
file2.addEventListener('change', updatePreviews)

clearBtn.addEventListener('click', ()=>{
  file1.value=''; file2.value=''; previewRow.innerHTML=''; showStatus('Cleared')
})

generateBtn.addEventListener('click', async ()=>{
  showStatus('Preparing images...')
  const f1 = file1.files[0]
  const f2 = file2.files[0]
  if(!f1 && !f2){ showStatus('Please upload at least one photo.'); return }
  const pose = document.getElementById('pose').value
  const fd = new FormData()
  if(f1) fd.append('image0', f1)
  if(f2) fd.append('image1', f2)
  fd.append('pose', pose)

  showStatus('Generating... (this may take a few seconds)')
  generateBtn.disabled = true
  try{
    // Send to API route at /api/hug-pose (server required)
    const res = await fetch('/api/hug-pose', { method:'POST', body:fd })
    if(!res.ok){ throw new Error('Server error') }
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    resultArea.innerHTML = ''
    const img = document.createElement('img')
    img.src = url
    resultArea.appendChild(img)
    downloadLink.href = url
    downloadLink.download = 'luka-result.png'
    downloadLink.style.display = 'inline-block'
    document.querySelector('.upload-card').style.display = 'none'
    resultCard.style.display = 'block'
    showStatus('Done')
  }catch(err){
    console.error(err)
    showStatus('Generation failed or server not configured. You can still upload to a hosted server later.')
  }finally{
    generateBtn.disabled = false
  }
})

backBtn.addEventListener('click', ()=>{
  resultCard.style.display='none'
  document.querySelector('.upload-card').style.display='block'
  showStatus('')
  resultArea.innerHTML=''
  downloadLink.style.display='none'
})

