
import React from 'react'

export default function UploadCard({ onFilesChange, files }){
  return (
    <div className="bg-white shadow rounded-xl p-5">
      <h3 className="text-lg font-semibold mb-3">Upload 1 or 2 photos</h3>
      <p className="text-sm text-gray-500 mb-4">Upload two faces to merge into a hug pose, or upload one photo and let Luka create a hugging companion.</p>

      <div className="flex flex-col gap-3">
        <input onChange={e => onFilesChange(e)} type="file" accept="image/*" />
        <input onChange={e => onFilesChange(e)} type="file" accept="image/*" />
      </div>

      {files && files.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-3">
          {Array.from(files).map((f, i) => (
            <img key={i} src={URL.createObjectURL(f)} className="w-full h-32 object-cover rounded-md" alt="preview" />
          ))}
        </div>
      )}
    </div>
  )
}
