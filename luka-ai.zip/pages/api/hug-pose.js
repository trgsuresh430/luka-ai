
import formidable from 'formidable'
import fs from 'fs'
import fetch from 'node-fetch'

export const config = {
  api: {
    bodyParser: false,
  }
}

async function saveTempFiles(req){
  const form = formidable({ multiples: true })
  return new Promise((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if(err) return reject(err)
      resolve({ fields, files })
    })
  })
}

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).end('Method not allowed')

  try{
    const { files, fields } = await saveTempFiles(req)
    const pose = (fields && fields.pose) || 'side-hug'
    const imagePaths = []
    Object.values(files).forEach(f => {
      const path = f.filepath || f.path || f.path
      imagePaths.push(path)
    })

    // If no HF key, return first image as fallback
    const HF_KEY = process.env.HUGGINGFACE_API_KEY || ''

    if(!HF_KEY){
      const first = fs.readFileSync(imagePaths[0])
      res.setHeader('Content-Type','image/png')
      return res.send(first)
    }

    // Read first image as base64 for payload
    const b64 = fs.readFileSync(imagePaths[0], { encoding: 'base64' })

    // Call a Hugging Face Space that supports image editing (PhotoMaker)
    // Endpoint: https://hf.space/embed/TencentARC/PhotoMaker/+/api/predict
    const payload = { data: ['data:image/png;base64,' + b64, pose] }

    const hfRes = await fetch('https://hf.space/embed/TencentARC/PhotoMaker/+/api/predict/', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${HF_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })

    if(!hfRes.ok){
      const txt = await hfRes.text()
      console.error('HF error', txt)
      const first = fs.readFileSync(imagePaths[0])
      res.setHeader('Content-Type','image/png')
      return res.send(first)
    }

    const hfJson = await hfRes.json()
    // Many Spaces return a base64 image inside hfJson.data[0] or hfJson.data
    const out = hfJson.data && hfJson.data[0]
    if(out && typeof out === 'string' && out.startsWith('data:image')){
      const b = out.split(',')[1]
      const buff = Buffer.from(b, 'base64')
      res.setHeader('Content-Type','image/png')
      return res.send(buff)
    }

    // fallback: return first image
    const first = fs.readFileSync(imagePaths[0])
    res.setHeader('Content-Type','image/png')
    return res.send(first)

  }catch(err){
    console.error(err)
    res.status(500).json({ error: 'Server error' })
  }
}
