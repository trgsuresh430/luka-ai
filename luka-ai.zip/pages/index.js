
import Head from 'next/head'
import { useState } from 'react'
import UploadCard from '../components/UploadCard'
import axios from 'axios'

export default function Home(){
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(false)
  const [resultUrl, setResultUrl] = useState(null)
  const [error, setError] = useState(null)
  const [pose, setPose] = useState('side-hug')

  function onFilesChange(e){
    const newFiles = Array.from(document.querySelectorAll('input[type=file]'))
      .map(i => i.files && i.files[0])
      .filter(Boolean)
    setFiles(newFiles)
  }

  async function onGenerate(){
    setError(null)
    if(files.length === 0){ setError('Please upload at least one photo.'); return }
    const form = new FormData()
    files.forEach((f,i) => form.append('image' + i, f))
    form.append('pose', pose)

    setLoading(true)
    try{
      const res = await axios.post('/api/hug-pose', form, { headers: { 'Content-Type': 'multipart/form-data' }, responseType: 'blob' })
      const url = URL.createObjectURL(res.data)
      setResultUrl(url)
    }catch(err){
      console.error(err)
      setError('Generation failed. See console for details.')
    }
    setLoading(false)
  }

  return (
    <div>
      <Head>
        <title>Luka AI — Hug Generator</title>
      </Head>

      <main className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-4xl">
          <header className="mb-8 flex items-center gap-4">
            <img src="/logo.png" alt="Luka AI" className="w-14 h-14 rounded-full" />
            <div>
              <h1 className="text-3xl font-bold">Luka AI</h1>
              <p className="text-sm text-gray-600">Free Hug & Couple Pose Generator — safe & SFW</p>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <UploadCard onFilesChange={onFilesChange} files={files} />

            <div className="bg-white shadow rounded-xl p-5 flex flex-col">
              <h3 className="text-lg font-semibold">Generate</h3>
              <p className="text-sm text-gray-500 mb-4">Click generate to create a hugging pose from the uploaded images.</p>

              <label className="text-sm mb-2">Pose</label>
              <select value={pose} onChange={e=>setPose(e.target.value)} className="mb-4 p-2 border rounded-md">
                <option value="side-hug">Side Hug</option>
                <option value="close-up">Close-up</option>
                <option value="holding-hands">Holding Hands</option>
                <option value="shoulder-lean">Shoulder Lean</option>
              </select>

              <button onClick={onGenerate} disabled={loading} className="mt-auto bg-purple-600 text-white py-3 rounded-md disabled:opacity-60">{loading ? 'Generating...' : 'Generate Hug Photo'}</button>

              {error && <p className="text-red-500 mt-3">{error}</p>}

              {resultUrl && (
                <div className="mt-4">
                  <h4 className="font-semibold mb-2">Result</h4>
                  <img src={resultUrl} alt="result" className="w-full rounded-md object-cover max-h-96" />
                  <a className="block mt-2 text-sm text-blue-600" href={resultUrl} download="luka-result.png">Download result</a>
                </div>
              )}
            </div>
          </div>

          <footer className="mt-8 text-center text-sm text-gray-500">Made with ❤️ • Luka AI — Free & Safe</footer>
        </div>
      </main>
    </div>
  )
}
