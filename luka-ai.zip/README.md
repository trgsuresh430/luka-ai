
# Luka AI (Free Hug Pose Generator)

This is a simple Next.js project that provides a free, SFW hug/couple pose generator UI and an API route that can proxy to a Hugging Face Space (PhotoMaker) for image editing. The project includes a safe fallback so it still works without an API key.

## How to run locally
1. npm install
2. Create .env.local (optional) with HUGGINGFACE_API_KEY
3. npm run dev
4. Open http://localhost:3000
